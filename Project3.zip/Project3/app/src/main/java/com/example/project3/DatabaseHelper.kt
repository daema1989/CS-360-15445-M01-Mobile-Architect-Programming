package com.example.project3

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import java.security.MessageDigest

/**
 * DatabaseHelper - Manages SQLite database for Weight Tracker app
 * 
 * Author: Todd Johnson
 * Course: CS-360 Mobile Architecture & Programming
 */
class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "WeightTracker.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_USERS = "users"
        private const val COLUMN_USER_ID = "user_id"
        private const val COLUMN_USERNAME = "username"
        private const val COLUMN_PASSWORD_HASH = "password_hash"
        private const val TABLE_WEIGHT_ENTRIES = "weight_entries"
        private const val COLUMN_ENTRY_ID = "entry_id"
        private const val COLUMN_ENTRY_USER_ID = "user_id"
        private const val COLUMN_DATE = "date"
        private const val COLUMN_WEIGHT = "weight"
        private const val TABLE_GOALS = "goals"
        private const val COLUMN_GOAL_ID = "goal_id"
        private const val COLUMN_GOAL_USER_ID = "user_id"
        private const val COLUMN_GOAL_WEIGHT = "goal_weight"
        private const val TAG = "DatabaseHelper"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        try {
            val createUsersTable = """
                CREATE TABLE $TABLE_USERS (
                    $COLUMN_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    $COLUMN_USERNAME TEXT UNIQUE NOT NULL,
                    $COLUMN_PASSWORD_HASH TEXT NOT NULL
                )
            """.trimIndent()
            db?.execSQL(createUsersTable)
            
            val createWeightEntriesTable = """
                CREATE TABLE $TABLE_WEIGHT_ENTRIES (
                    $COLUMN_ENTRY_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    $COLUMN_ENTRY_USER_ID INTEGER NOT NULL,
                    $COLUMN_DATE TEXT NOT NULL,
                    $COLUMN_WEIGHT REAL NOT NULL,
                    FOREIGN KEY($COLUMN_ENTRY_USER_ID) REFERENCES $TABLE_USERS($COLUMN_USER_ID)
                )
            """.trimIndent()
            db?.execSQL(createWeightEntriesTable)
            
            val createGoalsTable = """
                CREATE TABLE $TABLE_GOALS (
                    $COLUMN_GOAL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    $COLUMN_GOAL_USER_ID INTEGER UNIQUE NOT NULL,
                    $COLUMN_GOAL_WEIGHT REAL NOT NULL,
                    FOREIGN KEY($COLUMN_GOAL_USER_ID) REFERENCES $TABLE_USERS($COLUMN_USER_ID)
                )
            """.trimIndent()
            db?.execSQL(createGoalsTable)
        } catch (e: Exception) {
            Log.e(TAG, "Error creating database", e)
        }
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_WEIGHT_ENTRIES")
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_GOALS")
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        onCreate(db)
    }

    private fun hashPassword(password: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(password.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun registerUser(username: String, password: String): Boolean {
        val db = this.writableDatabase
        return try {
            val values = ContentValues().apply {
                put(COLUMN_USERNAME, username)
                put(COLUMN_PASSWORD_HASH, hashPassword(password))
            }
            db.insert(TABLE_USERS, null, values) != -1L
        } catch (e: Exception) {
            false
        } finally {
            db.close()
        }
    }

    fun validateUser(username: String, password: String): Int {
        val db = this.readableDatabase
        var userId = -1
        try {
            val cursor = db.query(TABLE_USERS, arrayOf(COLUMN_USER_ID),
                "$COLUMN_USERNAME = ? AND $COLUMN_PASSWORD_HASH = ?",
                arrayOf(username, hashPassword(password)), null, null, null)
            if (cursor.moveToFirst()) {
                userId = cursor.getInt(0)
            }
            cursor.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error validating user", e)
        } finally {
            db.close()
        }
        return userId
    }

    fun userExists(username: String): Boolean {
        val db = this.readableDatabase
        var exists = false
        try {
            val cursor = db.query(TABLE_USERS, arrayOf(COLUMN_USER_ID),
                "$COLUMN_USERNAME = ?", arrayOf(username), null, null, null)
            exists = cursor.count > 0
            cursor.close()
        } finally {
            db.close()
        }
        return exists
    }

    fun addWeightEntry(userId: Int, date: String, weight: Double): Boolean {
        val db = this.writableDatabase
        return try {
            val values = ContentValues().apply {
                put(COLUMN_ENTRY_USER_ID, userId)
                put(COLUMN_DATE, date)
                put(COLUMN_WEIGHT, weight)
            }
            db.insert(TABLE_WEIGHT_ENTRIES, null, values) != -1L
        } finally {
            db.close()
        }
    }

    fun getAllWeightEntries(userId: Int): List<WeightEntry> {
        val entries = mutableListOf<WeightEntry>()
        val db = this.readableDatabase
        try {
            val cursor = db.query(TABLE_WEIGHT_ENTRIES,
                arrayOf(COLUMN_ENTRY_ID, COLUMN_DATE, COLUMN_WEIGHT),
                "$COLUMN_ENTRY_USER_ID = ?", arrayOf(userId.toString()),
                null, null, "$COLUMN_DATE DESC")
            if (cursor.moveToFirst()) {
                do {
                    entries.add(WeightEntry(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getDouble(2)
                    ))
                } while (cursor.moveToNext())
            }
            cursor.close()
        } finally {
            db.close()
        }
        return entries
    }

    fun updateWeightEntry(entryId: Int, newWeight: Double): Boolean {
        val db = this.writableDatabase
        return try {
            val values = ContentValues().apply { put(COLUMN_WEIGHT, newWeight) }
            db.update(TABLE_WEIGHT_ENTRIES, values, "$COLUMN_ENTRY_ID = ?",
                arrayOf(entryId.toString())) > 0
        } finally {
            db.close()
        }
    }

    fun deleteWeightEntry(entryId: Int): Boolean {
        val db = this.writableDatabase
        return try {
            db.delete(TABLE_WEIGHT_ENTRIES, "$COLUMN_ENTRY_ID = ?",
                arrayOf(entryId.toString())) > 0
        } finally {
            db.close()
        }
    }

    fun setGoalWeight(userId: Int, goalWeight: Double): Boolean {
        val db = this.writableDatabase
        return try {
            val values = ContentValues().apply {
                put(COLUMN_GOAL_USER_ID, userId)
                put(COLUMN_GOAL_WEIGHT, goalWeight)
            }
            db.replace(TABLE_GOALS, null, values) != -1L
        } finally {
            db.close()
        }
    }

    fun getGoalWeight(userId: Int): Double? {
        val db = this.readableDatabase
        var goalWeight: Double? = null
        try {
            val cursor = db.query(TABLE_GOALS, arrayOf(COLUMN_GOAL_WEIGHT),
                "$COLUMN_GOAL_USER_ID = ?", arrayOf(userId.toString()), null, null, null)
            if (cursor.moveToFirst()) {
                goalWeight = cursor.getDouble(0)
            }
            cursor.close()
        } finally {
            db.close()
        }
        return goalWeight
    }
}

data class WeightEntry(val id: Int, val date: String, val weight: Double)
