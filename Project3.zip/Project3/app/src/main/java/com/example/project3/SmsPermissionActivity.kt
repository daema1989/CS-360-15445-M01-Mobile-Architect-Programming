package com.example.project3

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * SmsPermissionActivity - Handles SMS permission request
 * 
 * Author: Todd Johnson
 * Course: CS-360 Mobile Architecture & Programming
 */
class SmsPermissionActivity : AppCompatActivity() {

    private lateinit var permissionStatus: TextView
    private lateinit var enableButton: Button
    private lateinit var skipButton: Button
    private var userId: Int = -1
    private var username: String = ""

    companion object {
        private const val SMS_PERMISSION_REQUEST_CODE = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms_permission)

        userId = intent.getIntExtra("USER_ID", -1)
        username = intent.getStringExtra("USERNAME") ?: ""

        if (userId == -1) {
            Toast.makeText(this, "Error: User information not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        permissionStatus = findViewById(R.id.permissionStatus)
        enableButton = findViewById(R.id.enableButton)
        skipButton = findViewById(R.id.skipButton)

        updatePermissionStatus()
        
        enableButton.setOnClickListener { requestSmsPermission() }
        skipButton.setOnClickListener {
            Toast.makeText(this, "You can enable notifications later in Settings", Toast.LENGTH_SHORT).show()
            navigateToDataGrid()
        }
    }

    private fun updatePermissionStatus() {
        if (isSmsPermissionGranted()) {
            permissionStatus.text = "Status: Granted ✓"
            enableButton.isEnabled = false
            enableButton.text = "Permission Already Granted"
        } else {
            permissionStatus.text = "Status: Not Granted"
            enableButton.isEnabled = true
        }
    }

    private fun isSmsPermissionGranted(): Boolean {
        return ContextCompat.checkSelfPermission(
            this, Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestSmsPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
            Toast.makeText(this, 
                "SMS permission allows us to notify you when you reach your goal weight!",
                Toast.LENGTH_LONG).show()
        }
        ActivityCompat.requestPermissions(this, 
            arrayOf(Manifest.permission.SEND_SMS), SMS_PERMISSION_REQUEST_CODE)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            SMS_PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    updatePermissionStatus()
                    Toast.makeText(this, 
                        "Great! You'll receive SMS notifications when you reach your goal.",
                        Toast.LENGTH_SHORT).show()
                    skipButton.postDelayed({ navigateToDataGrid() }, 1500)
                } else {
                    Toast.makeText(this, 
                        "No problem! The app will work without SMS notifications.",
                        Toast.LENGTH_SHORT).show()
                    permissionStatus.text = "Status: Denied (App will work without SMS)"
                }
            }
        }
    }

    private fun navigateToDataGrid() {
        val intent = Intent(this, DataGridActivity::class.java)
        intent.putExtra("USER_ID", userId)
        intent.putExtra("USERNAME", username)
        startActivity(intent)
        finish()
    }
}
