package com.example.project3

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * WeightAdapter - RecyclerView adapter for displaying weight entries
 * 
 * Author: Todd Johnson
 * Course: CS-360 Mobile Architecture & Programming
 */
class WeightAdapter(
    private val weightEntries: MutableList<WeightEntry>,
    private val onDeleteClick: (WeightEntry) -> Unit,
    private val onUpdateClick: (WeightEntry) -> Unit
) : RecyclerView.Adapter<WeightAdapter.WeightViewHolder>() {

    class WeightViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val dateText: TextView = itemView.findViewById(R.id.dateText)
        val weightText: TextView = itemView.findViewById(R.id.weightText)
        val deleteButton: Button = itemView.findViewById(R.id.deleteButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WeightViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_weight_row, parent, false)
        return WeightViewHolder(view)
    }

    override fun onBindViewHolder(holder: WeightViewHolder, position: Int) {
        val entry = weightEntries[position]
        holder.dateText.text = entry.date
        holder.weightText.text = "${entry.weight} lbs"
        holder.deleteButton.setOnClickListener { onDeleteClick(entry) }
        holder.itemView.setOnClickListener { onUpdateClick(entry) }
    }

    override fun getItemCount(): Int = weightEntries.size
}
