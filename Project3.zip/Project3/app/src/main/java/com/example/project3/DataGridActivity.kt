package com.example.project3

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * DataGridActivity - Main screen with weight entries grid
 * 
 * Author: Todd Johnson
 * Course: CS-360 Mobile Architecture & Programming
 */
class DataGridActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var addEntryButton: Button
    private lateinit var goalWeightInput: EditText
    private lateinit var setGoalButton: Button
    private lateinit var currentGoalText: TextView
    private lateinit var welcomeText: TextView
    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var adapter: WeightAdapter
    private var weightEntries = mutableListOf<WeightEntry>()
    private var userId: Int = -1
    private var username: String = ""
    private var currentGoalWeight: Double? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_grid)

        userId = intent.getIntExtra("USER_ID", -1)
        username = intent.getStringExtra("USERNAME") ?: ""

        if (userId == -1) {
            Toast.makeText(this, "Error: User information not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        databaseHelper = DatabaseHelper(this)
        initializeViews()
        setupRecyclerView()
        loadWeightEntries()
        loadGoalWeight()
        setupClickListeners()
    }

    private fun initializeViews() {
        recyclerView = findViewById(R.id.weightRecyclerView)
        addEntryButton = findViewById(R.id.addEntryButton)
        goalWeightInput = findViewById(R.id.goalWeightInput)
        setGoalButton = findViewById(R.id.setGoalButton)
        currentGoalText = findViewById(R.id.currentGoalText)
        welcomeText = findViewById(R.id.welcomeText)
        welcomeText.text = "Welcome, $username!"
    }

    private fun setupRecyclerView() {
        adapter = WeightAdapter(
            weightEntries = weightEntries,
            onDeleteClick = { entry -> deleteWeightEntry(entry) },
            onUpdateClick = { entry -> showUpdateDialog(entry) }
        )
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)
    }

    private fun setupClickListeners() {
        addEntryButton.setOnClickListener { showAddEntryDialog() }
        setGoalButton.setOnClickListener { setGoalWeight() }
    }

    private fun loadWeightEntries() {
        weightEntries.clear()
        weightEntries.addAll(databaseHelper.getAllWeightEntries(userId))
        adapter.notifyDataSetChanged()
        checkGoalAchieved()
    }

    private fun loadGoalWeight() {
        currentGoalWeight = databaseHelper.getGoalWeight(userId)
        updateGoalDisplay()
    }

    private fun updateGoalDisplay() {
        currentGoalText.text = if (currentGoalWeight != null) {
            "Current Goal: $currentGoalWeight lbs"
        } else {
            "No goal set"
        }
    }

    private fun showAddEntryDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_entry, null)
        val weightInput = dialogView.findViewById<EditText>(R.id.weightInput)

        AlertDialog.Builder(this)
            .setTitle("Add Weight Entry")
            .setMessage("Enter your current weight")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val weightStr = weightInput.text.toString()
                if (weightStr.isNotEmpty()) {
                    val weight = weightStr.toDoubleOrNull()
                    if (weight != null && weight > 0) {
                        addWeightEntry(weight)
                    } else {
                        Toast.makeText(this, "Please enter a valid weight", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun addWeightEntry(weight: Double) {
        val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.US)
        val currentDate = dateFormat.format(Date())
        
        if (databaseHelper.addWeightEntry(userId, currentDate, weight)) {
            Toast.makeText(this, "Weight entry added!", Toast.LENGTH_SHORT).show()
            loadWeightEntries()
        } else {
            Toast.makeText(this, "Error adding entry", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showUpdateDialog(entry: WeightEntry) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_entry, null)
        val weightInput = dialogView.findViewById<EditText>(R.id.weightInput)
        weightInput.setText(entry.weight.toString())

        AlertDialog.Builder(this)
            .setTitle("Update Weight Entry")
            .setMessage("Editing entry from ${entry.date}")
            .setView(dialogView)
            .setPositiveButton("Update") { _, _ ->
                val weightStr = weightInput.text.toString()
                if (weightStr.isNotEmpty()) {
                    val newWeight = weightStr.toDoubleOrNull()
                    if (newWeight != null && newWeight > 0) {
                        updateWeightEntry(entry.id, newWeight)
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updateWeightEntry(entryId: Int, newWeight: Double) {
        if (databaseHelper.updateWeightEntry(entryId, newWeight)) {
            Toast.makeText(this, "Weight entry updated!", Toast.LENGTH_SHORT).show()
            loadWeightEntries()
        } else {
            Toast.makeText(this, "Error updating entry", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteWeightEntry(entry: WeightEntry) {
        AlertDialog.Builder(this)
            .setTitle("Delete Entry")
            .setMessage("Delete entry from ${entry.date}?")
            .setPositiveButton("Delete") { _, _ ->
                if (databaseHelper.deleteWeightEntry(entry.id)) {
                    Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show()
                    loadWeightEntries()
                } else {
                    Toast.makeText(this, "Error deleting entry", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun setGoalWeight() {
        val goalStr = goalWeightInput.text.toString()
        if (goalStr.isEmpty()) {
            Toast.makeText(this, "Please enter a goal weight", Toast.LENGTH_SHORT).show()
            return
        }

        val goal = goalStr.toDoubleOrNull()
        if (goal == null || goal <= 0) {
            Toast.makeText(this, "Please enter a valid weight", Toast.LENGTH_SHORT).show()
            return
        }

        if (databaseHelper.setGoalWeight(userId, goal)) {
            currentGoalWeight = goal
            updateGoalDisplay()
            Toast.makeText(this, "Goal weight set to $goal lbs!", Toast.LENGTH_SHORT).show()
            goalWeightInput.text.clear()
            checkGoalAchieved()
        } else {
            Toast.makeText(this, "Error setting goal weight", Toast.LENGTH_SHORT).show()
        }
    }

    private fun checkGoalAchieved() {
        if (currentGoalWeight == null || weightEntries.isEmpty()) return
        
        val latestWeight = weightEntries.first().weight
        if (latestWeight <= currentGoalWeight!!) {
            sendGoalAchievedNotification()
        }
    }

    private fun sendGoalAchievedNotification() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) 
            != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, 
                "Congratulations! You've reached your goal weight!",
                Toast.LENGTH_LONG).show()
            return
        }

        try {
            Toast.makeText(this, 
                "Goal achieved! SMS notification would be sent!",
                Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, 
                "Congratulations on reaching your goal!",
                Toast.LENGTH_LONG).show()
        }
    }
}
