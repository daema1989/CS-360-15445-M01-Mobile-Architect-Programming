package com.example.project3

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * LoginActivity - First screen of the Weight Tracker app
 * 
 * Author: Todd Johnson
 * Course: CS-360 Mobile Architecture & Programming
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var usernameInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var loginButton: Button
    private lateinit var createAccountButton: Button
    private lateinit var databaseHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        databaseHelper = DatabaseHelper(this)

        usernameInput = findViewById(R.id.usernameInput)
        passwordInput = findViewById(R.id.passwordInput)
        loginButton = findViewById(R.id.loginButton)
        createAccountButton = findViewById(R.id.createAccountButton)

        loginButton.setOnClickListener { handleLogin() }
        createAccountButton.setOnClickListener { handleCreateAccount() }
    }

    private fun handleLogin() {
        val username = usernameInput.text.toString().trim()
        val password = passwordInput.text.toString()

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show()
            return
        }

        val userId = databaseHelper.validateUser(username, password)
        if (userId != -1) {
            Toast.makeText(this, "Welcome back, $username!", Toast.LENGTH_SHORT).show()
            navigateToSmsPermission(userId, username)
        } else {
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()
            passwordInput.text.clear()
        }
    }

    private fun handleCreateAccount() {
        val username = usernameInput.text.toString().trim()
        val password = passwordInput.text.toString()

        if (username.isEmpty()) {
            Toast.makeText(this, "Please enter a username", Toast.LENGTH_SHORT).show()
            return
        }

        if (username.length < 3) {
            Toast.makeText(this, "Username must be at least 3 characters", Toast.LENGTH_SHORT).show()
            return
        }

        if (password.isEmpty()) {
            Toast.makeText(this, "Please enter a password", Toast.LENGTH_SHORT).show()
            return
        }

        if (password.length < 6) {
            Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
            return
        }

        if (databaseHelper.userExists(username)) {
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show()
            return
        }

        if (databaseHelper.registerUser(username, password)) {
            Toast.makeText(this, "Account created! Welcome, $username!", Toast.LENGTH_SHORT).show()
            val userId = databaseHelper.validateUser(username, password)
            navigateToSmsPermission(userId, username)
        } else {
            Toast.makeText(this, "Error creating account", Toast.LENGTH_SHORT).show()
        }
    }

    private fun navigateToSmsPermission(userId: Int, username: String) {
        val intent = Intent(this, SmsPermissionActivity::class.java)
        intent.putExtra("USER_ID", userId)
        intent.putExtra("USERNAME", username)
        startActivity(intent)
    }
}
